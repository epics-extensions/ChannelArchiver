// Dummy file to allow the C++Builder XercesLib project to use
// the same Version resource file as Visual C++
