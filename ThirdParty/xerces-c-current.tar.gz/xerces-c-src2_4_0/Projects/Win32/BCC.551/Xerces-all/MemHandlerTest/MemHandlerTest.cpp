
#pragma hdrstop

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

#ifdef NEVER_COMPILE
#include <stdio.h>

// Dummy entry point to satisfy the BCB IDE
int main(int argc, char* argv[])
{
	printf("*** Compile XercesC Library with Deprecated DOM API for this test\n");
	return 0;
}
#endif

// The real entry point is in the Samples folder
//#include <MemoryMonitor.cpp>
